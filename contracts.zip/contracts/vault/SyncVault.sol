// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import "@openzeppelin/contracts-upgradeable/token/ERC20/ERC20Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC20/extensions/ERC4626Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "../interfaces/identity/IIdentityRegistry.sol";
import "../interfaces/vault/ISyncVault.sol";
import "../interfaces/financial/IFeeEngine.sol";
import "../interfaces/financial/INAVOracle.sol";
import "../utils/AssetConfig.sol";
import "./BaseVault.sol";

/**
 * @title SyncVault
 * @dev Upgradeable ERC-4626 Tokenized Vault with synchronous deposit/redeem
 * Compatible with Clones (ERC-1167)
 */
contract SyncVault is 
    Initializable, 
    ERC4626Upgradeable, 
    AccessControlUpgradeable, 
    ReentrancyGuardUpgradeable,
    ISyncVault,
    BaseVault
{
    using SafeERC20 for IERC20;

    // === State ===
    address public identityRegistry;
    address public complianceModule;
    address public circuitBreaker;
    bytes32 public category;

    // ─── FeeEngine / NAVOracle Integration (§5.1) ────────────
    address public feeEngine;
    address public navOracle;
    bytes32 public assetId;

    bytes32 public constant FEE_ENGINE_ROLE = keccak256("FEE_ENGINE_ROLE");
    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");

    // === Holder Tracking ===
    address[] private _holderList;
    mapping(address => bool) private _isHolder;

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    function initialize(
        address asset_,
        string memory name_,
        string memory symbol_,
        address admin,
        address assetRegistry_
    ) public initializer {
        __ERC4626_init(IERC20(asset_));
        __ERC20_init(name_, symbol_);
        __AccessControl_init();
        __ReentrancyGuard_init();
        __BaseVault_init(asset_, assetRegistry_);

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(DEFAULT_ADMIN_ROLE, _msgSender()); // Grant to Factory for configuration
        _grantRole(OPERATOR_ROLE, admin);
        _grantRole(COMPLIANCE_ROLE, admin);
        // OZ ERC-4626 v5 virtual shares (+1 on both sides of the conversion formula)
        // already protect against donation/inflation attacks.
        // No dead share needed — that pattern caused a 2:1 mint ratio on first deposit.
    }

    function decimals() public view override(ERC20Upgradeable, ERC4626Upgradeable) returns (uint8) {
        return super.decimals();
    }

    // === Overrides ===

    function asset() public view override(ERC4626Upgradeable, ISyncVault) returns (address) {
        return super.asset();
    }

    function totalAssets() public view override(ERC4626Upgradeable, ISyncVault, BaseVault) returns (uint256) {
        return IERC20(asset()).balanceOf(address(this));
    }

    function _convertToShares(uint256 assets, Math.Rounding) internal pure override returns (uint256) {
        return assets;
    }

    function _convertToAssets(uint256 shares, Math.Rounding) internal pure override returns (uint256) {
        return shares;
    }

    function convertToAssets(uint256 shares) public pure override(ERC4626Upgradeable, ISyncVault) returns (uint256) {
        return shares;
    }

    function convertToShares(uint256 assets) public pure override(ERC4626Upgradeable, ISyncVault) returns (uint256) {
        return assets;
    }

    function maxDeposit(address receiver) public view override(ERC4626Upgradeable, ISyncVault) returns (uint256) {
        return super.maxDeposit(receiver);
    }

    function maxMint(address receiver) public view override(ERC4626Upgradeable, ISyncVault) returns (uint256) {
        return super.maxMint(receiver);
    }

    function maxWithdraw(address owner) public view override(ERC4626Upgradeable, ISyncVault) returns (uint256) {
        return super.maxWithdraw(owner);
    }

    function maxRedeem(address owner) public view override(ERC4626Upgradeable, ISyncVault) returns (uint256) {
        return super.maxRedeem(owner);
    }

    function deposit(uint256 assets, address receiver) public override(ERC4626Upgradeable, ISyncVault) nonReentrant returns (uint256) {
        _checkCompliance(msg.sender);
        if (feeEngine != address(0)) {
            IFeeEngine(feeEngine).checkpoint(address(this));
        }
        if (navOracle != address(0)) {
            INAVOracle(navOracle).assertDepositAllowed(assetId);
        }
        uint256 entryFee = _calcEntryFee(assets, receiver);
        if (entryFee > 0) {
            address usdcToken = address(IFeeEngine(feeEngine).usdc());
            uint256 entryFeeUSDC = _scaleDecimals(asset(), usdcToken, entryFee);
            if (entryFeeUSDC > 0) {
                IERC20(usdcToken).safeTransferFrom(msg.sender, feeEngine, entryFeeUSDC);
                IFeeEngine(feeEngine).receiveFee(address(this), entryFeeUSDC);
            }
        }
        return super.deposit(assets, receiver);
    }

    function mint(uint256 shares, address receiver) public override(ERC4626Upgradeable, ISyncVault) nonReentrant returns (uint256) {
        _checkCompliance(msg.sender);
        if (feeEngine != address(0)) {
            IFeeEngine(feeEngine).checkpoint(address(this));
        }
        if (navOracle != address(0)) {
            INAVOracle(navOracle).assertDepositAllowed(assetId);
        }
        uint256 assets = super.mint(shares, receiver);
        uint256 entryFee = _calcEntryFee(assets, receiver);
        if (entryFee > 0) {
            address usdcToken = address(IFeeEngine(feeEngine).usdc());
            uint256 entryFeeUSDC = _scaleDecimals(asset(), usdcToken, entryFee);
            if (entryFeeUSDC > 0) {
                IERC20(usdcToken).safeTransferFrom(msg.sender, feeEngine, entryFeeUSDC);
                IFeeEngine(feeEngine).receiveFee(address(this), entryFeeUSDC);
            }
        }
        return assets;
    }

    function withdraw(uint256 assets, address receiver, address owner) public override(ERC4626Upgradeable, ISyncVault) nonReentrant returns (uint256) {
        _checkCompliance(owner);
        if (feeEngine != address(0)) {
            IFeeEngine(feeEngine).checkpoint(address(this));
        }
        uint256 exitFee = _calcExitFee(assets, owner);
        uint256 shares = previewWithdraw(assets);
        _withdraw(_msgSender(), receiver, owner, assets, shares);
        if (exitFee > 0) {
            address usdcToken = address(IFeeEngine(feeEngine).usdc());
            uint256 exitFeeUSDC = _scaleDecimals(asset(), usdcToken, exitFee);
            if (exitFeeUSDC > 0) {
                IERC20(usdcToken).safeTransferFrom(owner, feeEngine, exitFeeUSDC);
                IFeeEngine(feeEngine).receiveFee(address(this), exitFeeUSDC);
            }
        }
        return shares;
    }

    function redeem(uint256 shares, address receiver, address owner) public override(ERC4626Upgradeable, ISyncVault) nonReentrant returns (uint256) {
        _checkCompliance(owner);
        if (feeEngine != address(0)) {
            IFeeEngine(feeEngine).checkpoint(address(this));
        }
        uint256 assets = previewRedeem(shares);
        uint256 exitFee = _calcExitFee(assets, owner);
        _withdraw(_msgSender(), receiver, owner, assets, shares);
        if (exitFee > 0) {
            address usdcToken = address(IFeeEngine(feeEngine).usdc());
            uint256 exitFeeUSDC = _scaleDecimals(asset(), usdcToken, exitFee);
            if (exitFeeUSDC > 0) {
                IERC20(usdcToken).safeTransferFrom(owner, feeEngine, exitFeeUSDC);
                IFeeEngine(feeEngine).receiveFee(address(this), exitFeeUSDC);
            }
        }
        return assets;
    }

    // ─── Fee Helpers ────────────────────────────────────────

    function _calcEntryFee(uint256 assets, address investor) internal view returns (uint256) {
        if (feeEngine == address(0)) return 0;
        return IFeeEngine(feeEngine).calculateEntryFee(address(this), assets, investor);
    }

    function _calcExitFee(uint256 assets, address owner) internal view returns (uint256) {
        if (feeEngine == address(0)) return 0;
        return IFeeEngine(feeEngine).calculateExitFee(address(this), assets, owner);
    }

    function _scaleDecimals(address fromToken, address toToken, uint256 amount) internal view returns (uint256) {
        if (fromToken == toToken) return amount;
        uint8 fromDecimals = IERC20Metadata(fromToken).decimals();
        uint8 toDecimals = IERC20Metadata(toToken).decimals();
        if (fromDecimals == toDecimals) return amount;
        if (fromDecimals > toDecimals) {
            return amount / (10 ** (fromDecimals - toDecimals));
        } else {
            return amount * (10 ** (toDecimals - fromDecimals));
        }
    }

    // ─── Setters ────────────────────────────────────────────

    function setFeeEngine(address _feeEngine) external onlyRole(DEFAULT_ADMIN_ROLE) {
        feeEngine = _feeEngine;
    }

    function setNavOracle(address _navOracle) external onlyRole(DEFAULT_ADMIN_ROLE) {
        navOracle = _navOracle;
    }

    function setAssetId(bytes32 _assetId) external onlyRole(DEFAULT_ADMIN_ROLE) {
        assetId = _assetId;
    }

    function distributeYield(uint256 amount) external override onlyRole(OPERATOR_ROLE) {
        require(amount > 0, "SyncVault: Amount must be positive");
        IERC20(asset()).safeTransferFrom(msg.sender, address(this), amount);
        _afterYieldDistribution();
    }

    // === Identity & Compliance ===

    function _checkCompliance(address account) internal view {
        if (identityRegistry == address(0)) return;
        require(IIdentityRegistry(identityRegistry).isVerified(account), "SyncVault: Account not verified");
    }

    function setIdentityRegistry(address registry) external override onlyRole(DEFAULT_ADMIN_ROLE) {
        require(registry != address(0), "invalid registry");
        identityRegistry = registry;
    }

    function setComplianceModule(address compliance) external override onlyRole(DEFAULT_ADMIN_ROLE) {
        require(compliance != address(0), "invalid compliance");
        complianceModule = compliance;
    }

    function setCircuitBreaker(address cb) external override onlyRole(DEFAULT_ADMIN_ROLE) {
        require(cb != address(0), "invalid cb");
        circuitBreaker = cb;
    }

    function emergencyWithdraw(uint256 amount, address to) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(to != address(0), "invalid to address");
        IERC20(asset()).safeTransfer(to, amount);
    }

    function setCategory(bytes32 category_) external override {
        category = category_;
    }

    function version() external pure override returns (string memory) {
        return AssetConfig.VERSION;
    }

    // Boilerplate for ISyncVault
    function totalMinted() external view override returns (uint256) { return totalSupply(); }
    function totalBurned() external pure override returns (uint256) { return 0; }

    // === BaseVault Implementation ===

    function _update(
        address from,
        address to,
        uint256 value
    ) internal override(ERC20Upgradeable, BaseVault) {
        // Track unique holders
        if (to != address(0) && !_isHolder[to]) {
            _holderList.push(to);
            _isHolder[to] = true;
        }
        
        // Note: we don't remove from list for gas efficiency, 
        // _getHolderCount filters by balanceOf.
        if (from != address(0) && balanceOf(from) == 0) {
            _isHolder[from] = false;
        }

        super._update(from, to, value);
    }

    function _getHolderCount() internal view override returns (uint256) {
        uint256 count;
        uint256 len = _holderList.length;
        for (uint256 i = 0; i < len; i++) {
            if (_isHolder[_holderList[i]]) count++;
        }
        return count;
    }

    function _getAllHolders() internal view override
        returns (address[] memory holders, uint256[] memory shares)
    {
        uint256 count = _getHolderCount();
        holders = new address[](count);
        shares = new uint256[](count);
        uint256 idx;
        uint256 len = _holderList.length;
        for (uint256 i = 0; i < len; i++) {
            address h = _holderList[i];
            if (_isHolder[h]) {
                holders[idx] = h;
                shares[idx] = balanceOf(h);
                idx++;
            }
        }
    }
}
